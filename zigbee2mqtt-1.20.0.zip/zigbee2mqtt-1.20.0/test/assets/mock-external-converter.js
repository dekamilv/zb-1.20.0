const mockDevice = {
    mock: true,
    zigbeeModel: ['external_converter_device'],
    vendor: 'external',
    model: 'external_converter_device',
    description: 'external',
    fromZigbee: [],
    toZigbee: [],
    exposes: [],
};

module.exports = mockDevice;